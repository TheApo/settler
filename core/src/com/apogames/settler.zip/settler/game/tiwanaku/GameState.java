package com.apogames.settler.game.tiwanaku;

public enum GameState {
    PLAY,
    SOLVED
}
