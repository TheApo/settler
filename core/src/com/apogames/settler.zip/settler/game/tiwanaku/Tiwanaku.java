package com.apogames.settler.game.tiwanaku;

import com.apogames.settler.Constants;
import com.apogames.settler.asset.AssetLoader;
import com.apogames.settler.backend.DrawString;
import com.apogames.settler.backend.SequentiallyThinkingScreenModel;
import com.apogames.settler.common.Localization;
import com.apogames.settler.entity.ApoButton;
import com.apogames.settler.game.MainPanel;
import com.apogames.settler.level.LevelCreate;
import com.apogames.settler.level.Level;
import com.apogames.settler.level.Solve;
import com.apogames.settler.level.helper.Difficulty;
import com.apogames.settler.level.helper.FillHelp;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

import java.util.ArrayList;

public class Tiwanaku extends SequentiallyThinkingScreenModel {

    private final int addX = 10;
    private final int addY = 100;

    private int addXScale = 0;

    public static final String FUNCTION_TIWANAKU_BACK = "TIWANAKU_QUIT";
    public static final String FUNCTION_NEW_LEVEL = "TIWANAKU_NEW_LEVEL";
    public static final String FUNCTION_RESTART = "TIWANAKU_RESTART";
    public static final String FUNCTION_FIX = "TIWANAKU_FIX";
    public static final String FUNCTION_HELP = "TIWANAKU_HELP";

    private final boolean[] keys = new boolean[256];

    private boolean isPressed = false;

    private LevelCreate levelCreate;

    private Level level;

    private LevelSize levelSize = LevelSize.SMALL;

    private boolean newLevel = false;

    private Solve solve;

    private GameState gameState = GameState.PLAY;

    private boolean help;

    private Difficulty difficulty;

    public Tiwanaku(final MainPanel game) {
        super(game);
    }

    public void setNeededButtonsVisible() {
        getMainPanel().getButtonByFunction(FUNCTION_TIWANAKU_BACK).setVisible(true);
        getMainPanel().getButtonByFunction(FUNCTION_RESTART).setVisible(true);
        getMainPanel().getButtonByFunction(FUNCTION_FIX).setVisible(true);
        getMainPanel().getButtonByFunction(FUNCTION_NEW_LEVEL).setVisible(true);
        getMainPanel().getButtonByFunction(FUNCTION_HELP).setVisible(true);
    }

    public void setValues(LevelSize levelSize, boolean newLevel, Difficulty difficulty) {
        this.levelSize = levelSize;
        this.newLevel = newLevel;
        this.difficulty = difficulty;
    }

    @Override
    public void init() {
        if (getGameProperties() == null) {
            setGameProperties(new TiwanakuPreferences(this));
            loadProperties();
        }
        if (this.levelCreate == null || this.newLevel) {
            this.createNewLevel();
        }

        this.getMainPanel().resetSize(Constants.GAME_WIDTH, Constants.GAME_HEIGHT);

        this.setNeededButtonsVisible();
        this.setButtonsVisibility();
    }

    @Override
    public void keyPressed(int keyCode, char character) {
        super.keyPressed(keyCode, character);

        keys[keyCode] = true;
    }

    private void createNewLevel() {
        this.levelCreate = new LevelCreate(this.difficulty);

        this.levelCreate.createLevel(this.levelSize.getX(), this.levelSize.getY(), this.levelSize.getFiveCount(), this.levelSize.getFourCount());
        this.level = this.levelCreate.getLevel();
        this.setSolve();
        this.gameState = GameState.PLAY;

        this.getMainPanel().getButtonByFunction(FUNCTION_NEW_LEVEL).setVisible(true);

        this.addXScale = (int)((9 - this.level.getBackground()[0].length) * AssetLoader.backgroundTextureRegion[4].getRegionWidth() / 2f);
    }

    private void setSolve() {
        this.solve = new Solve(this.level.getBackground());
        this.solve.setPossibleValues(this.level.getCurNumber());
    }

    @Override
    public void keyButtonReleased(int keyCode, char character) {
        super.keyButtonReleased(keyCode, character);

        if (keyCode == Input.Keys.N) {
            this.createNewLevel();
        }

        keys[keyCode] = false;
    }

    public void mouseMoved(int mouseX, int mouseY) {
    }

    public void mouseButtonReleased(int mouseX, int mouseY, boolean isRightButton) {
        this.isPressed = false;

        if (this.gameState == GameState.SOLVED) {
            return;
        }

        int tileSize = AssetLoader.backgroundTextureRegion[4].getRegionWidth();
        if (this.addX + addXScale < mouseX && this.addX + addXScale + tileSize * this.level.getBackground()[0].length > mouseX &&
            this.addY < mouseY && this.addY + tileSize * this.level.getBackground().length > mouseY) {
            int x = (mouseX - this.addX - addXScale) / tileSize;
            int y = (mouseY - this.addY) / tileSize;
            if (this.level.getFixedNumbers()[y][x] == 0) {
                byte add = (byte) (isRightButton ? -1 : 1);
                this.level.getCurNumber()[y][x] = (byte) (this.level.getCurNumber()[y][x] + add);
                if (this.level.getCurNumber()[y][x] > this.level.getRegion()[y][x]) {
                    this.level.getCurNumber()[y][x] = 0;
                }
                if (this.level.getCurNumber()[y][x] < 0) {
                    this.level.getCurNumber()[y][x] = this.level.getRegion()[y][x];
                }
                this.setSolve();
                if (this.level.isSolved()) {
                    this.gameSolved();
                }
            }
        }
    }

    private void gameSolved() {
        this.gameState = GameState.SOLVED;
        this.getMainPanel().getButtonByFunction(FUNCTION_NEW_LEVEL).setVisible(true);
        this.getMainPanel().getButtonByFunction(FUNCTION_RESTART).setVisible(true);
        this.getMainPanel().getButtonByFunction(FUNCTION_FIX).setVisible(true);
    }

    public void mousePressed(int x, int y, boolean isRightButton) {
        if (isRightButton && !this.isPressed) {
            this.isPressed = true;
        }
    }

    public void mouseDragged(int x, int y, boolean isRightButton) {
        if (isRightButton) {
            if (!this.isPressed) {
                this.mousePressed(x, y, isRightButton);
            }
        }
    }

    @Override
    public void mouseButtonFunction(String function) {
        super.mouseButtonFunction(function);
        switch (function) {
            case Tiwanaku.FUNCTION_TIWANAKU_BACK:
                quit();
                break;
            case Tiwanaku.FUNCTION_NEW_LEVEL:
                createNewLevel();
                break;
            case Tiwanaku.FUNCTION_RESTART:
                restartLevel();
                break;
            case Tiwanaku.FUNCTION_FIX:
                saveCurrentFixLevel();
                break;
            case Tiwanaku.FUNCTION_HELP:
                this.help = !this.help;
                break;
        }
    }

    private void saveCurrentFixLevel() {
        this.level.fix();
    }

    private void restartLevel() {
        this.level.restart();
    }

    private void setButtonsVisibility() {
    }

    public void mouseWheelChanged(int changed) {
    }

    @Override
    protected void quit() {
        getMainPanel().changeToMenu();
    }

    @Override
    public void doThink(float delta) {

    }

    @Override
    public void render() {
        getMainPanel().getRenderer().begin(ShapeRenderer.ShapeType.Filled);

        getMainPanel().getRenderer().setColor(Constants.COLOR_PURPLE_MENU[0], Constants.COLOR_PURPLE_MENU[1], Constants.COLOR_PURPLE_MENU[2], 1f);

        getMainPanel().getRenderer().end();

        getMainPanel().spriteBatch.begin();

        int tileSizeWidth = AssetLoader.backgroundTextureRegion[4].getRegionWidth();
        int tileSizeHeight = AssetLoader.backgroundTextureRegion[4].getRegionHeight();
        float smaller = 0.5f;
        int addSmall = 900;
        for (int y = 0; y < this.level.getCurBackground().length; y++) {
            for (int x = 0; x < this.level.getCurBackground()[0].length; x++) {
                //if (this.level.getCurBackground()[y][x] > 0) {
                if (this.level.getBackground()[y][x] > 0) {
                    getMainPanel().spriteBatch.draw(AssetLoader.backgroundTextureRegion[this.level.getBackground()[y][x] - 1], x * tileSizeWidth + addX + addXScale, addY + y * tileSizeWidth - (tileSizeHeight - tileSizeWidth));
                } else {
                    getMainPanel().spriteBatch.draw(AssetLoader.backgroundTextureRegion[4], x * tileSizeWidth + addX + addXScale, addY + y * tileSizeWidth - (tileSizeHeight - tileSizeWidth));
                }
                if (this.level.getCurNumber()[y][x] > 0) {
                    getMainPanel().spriteBatch.draw(AssetLoader.circlesTextureRegion[this.level.getCurNumber()[y][x] - 1], x * tileSizeWidth + addX + addXScale + tileSizeWidth/2f - AssetLoader.circlesTextureRegion[this.level.getCurNumber()[y][x] - 1].getRegionWidth()/2f, addY + y * tileSizeWidth + tileSizeWidth/2f - AssetLoader.circlesTextureRegion[this.level.getCurNumber()[y][x] - 1].getRegionHeight()/2f);
                    if (this.level.getFixedNumbers()[y][x] > 0) {
                        getMainPanel().spriteBatch.draw(AssetLoader.circlesTextureRegion[5], x * tileSizeWidth + addX + addXScale + tileSizeWidth / 2f - AssetLoader.circlesTextureRegion[5].getRegionWidth() / 2f, addY + y * tileSizeWidth + tileSizeWidth / 2f - AssetLoader.circlesTextureRegion[5].getRegionHeight() / 2f);
                    }
                    //getMainPanel().drawString(String.valueOf(this.level.getCurNumber()[y][x]), x * tileSizeWidth + addX + tileSizeWidth/2f, addY + y * tileSizeWidth + tileSizeWidth/2f, Constants.COLOR_WHITE, AssetLoader.font40, DrawString.MIDDLE, true, false);
                    getMainPanel().drawString(String.valueOf(this.level.getCurNumber()[y][x]), x * tileSizeWidth + addX + addXScale + tileSizeWidth/2f, addY + y * tileSizeWidth + tileSizeWidth/2f + 4, Constants.COLOR_BLACK, AssetLoader.font40, DrawString.MIDDLE, true, false);
                }

                if (this.help && this.level.getCurNumber()[y][x] == 0) {
                    ArrayList<Byte> possibleValues = this.solve.getPossibleValues()[y][x].getPossibleValues();
                    for (int value : possibleValues) {
                        int addValueX = (value - 1) * tileSizeWidth/4 + 10;
                        if (value > 3) {
                            addValueX = (value - 4) * tileSizeWidth/4 + 10;
                        }
                        int addValueY = -15;
                        if (value > 3) {
                            addValueY += tileSizeWidth/4;
                        }
                        getMainPanel().spriteBatch.draw(AssetLoader.circlesTextureRegion[value-1], x * tileSizeWidth + addX + addXScale + addValueX, addY + addValueY + y * tileSizeWidth + tileSizeWidth/2f - AssetLoader.circlesTextureRegion[value].getRegionHeight()/2f, AssetLoader.circlesTextureRegion[value].getRegionWidth()/2f, AssetLoader.circlesTextureRegion[value].getRegionHeight()/2f);
                    }
                }

//                getMainPanel().spriteBatch.draw(AssetLoader.backgroundTextureRegion[this.level.getBackground()[y][x] - 1], x * tileSizeWidth * smaller + addX + addSmall, addY + y * tileSizeWidth * smaller - (tileSizeHeight - tileSizeWidth) * smaller, tileSizeWidth * smaller, tileSizeHeight * smaller);
//                getMainPanel().drawString(String.valueOf(this.level.getNumbers()[y][x]), x * tileSizeWidth * smaller + addX + addSmall + tileSizeWidth * smaller/2f + 1, addY + y * tileSizeWidth * smaller + tileSizeWidth * smaller/2f + 1, Constants.COLOR_BLACK, AssetLoader.font30, DrawString.MIDDLE, true, false);
//
//                int addSolveY = 350;
//                getMainPanel().spriteBatch.draw(AssetLoader.backgroundTextureRegion[this.level.getBackground()[y][x] - 1], x * tileSizeWidth * smaller + addX + addSmall, addY + addSolveY + y * tileSizeWidth * smaller - (tileSizeHeight - tileSizeWidth) * smaller, tileSizeWidth * smaller, tileSizeHeight * smaller);
//                getMainPanel().drawString(String.valueOf(this.level.getSolvedNumbers()[y][x]), x * tileSizeWidth * smaller + addX + addSmall + tileSizeWidth * smaller/2f + 1, addY + addSolveY + y * tileSizeWidth * smaller + tileSizeWidth * smaller/2f + 1, Constants.COLOR_BLACK, AssetLoader.font30, DrawString.MIDDLE, true, false);
            }
        }

        getMainPanel().drawString(Constants.PROPERTY_NAME, Constants.GAME_WIDTH/2f, 40, Constants.COLOR_PURPLE, AssetLoader.font40, DrawString.MIDDLE, true, false);

        if (this.gameState == GameState.SOLVED) {
            ApoButton button = this.getMainPanel().getButtonByFunction(FUNCTION_NEW_LEVEL);
            getMainPanel().drawString(Localization.getInstance().getCommon().get("won"), button.getXMiddle(), addY, Constants.COLOR_PURPLE, AssetLoader.font30, DrawString.MIDDLE, false, false);
        }

        getMainPanel().spriteBatch.end();

        for (ApoButton button : this.getMainPanel().getButtons()) {
            button.render(this.getMainPanel());
        }
    }

//	        Gdx.graphics.getGL20().glEnable(GL20.GL_BLEND);
//			Gdx.graphics.getGL20().glDisable(GL20.GL_BLEND);
//
//			getMainPanel().getRenderer().begin(ShapeType.Line);
//			getMainPanel().getRenderer().setColor(Constants.COLOR_WHITE[0], Constants.COLOR_WHITE[1], Constants.COLOR_WHITE[2], 1f);
//			getMainPanel().getRenderer().roundedRectLine((WIDTH - width)/2f, startY, width, height, 5);
//			getMainPanel().getRenderer().end();


    public void drawOverlay() {
    }

    @Override
    public void dispose() {
    }
}
